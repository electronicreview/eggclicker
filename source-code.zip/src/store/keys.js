
const app = "@egg_clicker_";

// storing variable names as strings to avoid typo
module.exports = {
    total: `${app}total`,
    increment: `${app}increment`
};